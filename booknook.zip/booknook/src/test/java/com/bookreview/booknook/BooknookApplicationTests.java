package com.bookreview.booknook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooknookApplicationTests {

	@Test
	void contextLoads() {
	}

}
